import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/DepositServlet")
public class DepositServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accNumber = request.getParameter("accNo");
        String amountStr = request.getParameter("amount");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (accNumber == null || amountStr == null || accNumber.trim().isEmpty() || amountStr.trim().isEmpty()) {
            out.println("<h3 style='color:red;'>All fields are required. <a href='Deposit.html'>Try again</a></h3>");
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
            if (amount <= 0) {
                out.println("<h3 style='color:red;'>Amount must be greater than zero. <a href='Deposit.html'>Try again</a></h3>");
                return;
            }
        } catch (NumberFormatException e) {
            out.println("<h3 style='color:red;'>Invalid amount. <a href='Deposit.html'>Try again</a></h3>");
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/user_auth", "root", "2341");

            // Check if account exists
            String checkQuery = "SELECT balance FROM accounts WHERE account_number = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
            checkStmt.setString(1, accNumber);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                double currentBalance = rs.getDouble("balance");
                double newBalance = currentBalance + amount;

                // Update balance
                String updateQuery = "UPDATE accounts SET balance = ? WHERE account_number = ?";
                PreparedStatement updateStmt = conn.prepareStatement(updateQuery);
                updateStmt.setDouble(1, newBalance);
                updateStmt.setString(2, accNumber);

                int updated = updateStmt.executeUpdate();
                if (updated > 0) {
                	String logQuery = "INSERT INTO transactions (account_number, type, amount) VALUES (?, 'Deposit', ?)";
                	PreparedStatement logStmt = conn.prepareStatement(logQuery);
                	logStmt.setString(1, accNumber);
                	logStmt.setDouble(2, amount);
                	logStmt.executeUpdate();
                	logStmt.close();

                	out.println("<h3 style='color:green;'>Amount deposited successfully! New Balance: ₹" + newBalance + "</h3>");
                	out.println("<div style='margin-top:20px;'><a href='Dashboard.html' style='color:#4285F4; text-decoration:none; font-weight:bold;'>← Back to Dashboard</a></div>");
                } else {
                    out.println("<h3 style='color:red;'>Failed to deposit amount. <a href='Deposit.html'>Try again</a></h3>");
                }

                updateStmt.close();
            } else {
                out.println("<h3 style='color:red;'>Account not found. <a href='Deposit.html'>Try again</a></h3>");
            }

            rs.close();
            checkStmt.close();
            conn.close();

        } catch (Exception e) {
            out.println("<h3 style='color:red;'>Database error: " + e.getMessage() + "</h3>");
        }
    }
}
