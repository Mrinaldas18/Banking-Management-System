import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/Registration")
public class Registration extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("pwd");
        String cnfpwd = request.getParameter("cnfpwd");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (name == null || email == null || password == null || cnfpwd == null ||
            name.trim().isEmpty() || email.trim().isEmpty() || password.trim().isEmpty() || cnfpwd.trim().isEmpty()) {
            out.println("<h3>All fields are required. <a href='registration.html'>Try again</a></h3>");
            return;
        }

        if (!password.equals(cnfpwd)) {
            out.println("<h3>Passwords do not match. <a href='Registration.html'>Try again</a></h3>");
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // ✅ Load driver manually

            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/user_auth", "root", "2341")) {

                // Check if email already exists
                String checkQuery = "SELECT id FROM users WHERE email = ?";
                PreparedStatement checkStmt = con.prepareStatement(checkQuery);
                checkStmt.setString(1, email);
                ResultSet rs = checkStmt.executeQuery();

                if (rs.next()) {
                    out.println("<h3>Email already registered. <a href='Login.html'>Login here</a></h3>");
                } else {
                    // Insert user
                    String insertQuery = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
                    PreparedStatement insertStmt = con.prepareStatement(insertQuery);
                    insertStmt.setString(1, name);
                    insertStmt.setString(2, email);
                    insertStmt.setString(3, password); // (In real apps, hash the password)
                    insertStmt.executeUpdate();

                    response.sendRedirect("Login.html");
                }

            } catch (SQLException e) {
                out.println("<h3>Database error: " + e.getMessage() + "</h3>");
                e.printStackTrace();
            }

        } catch (ClassNotFoundException e) {
            out.println("<h3>JDBC Driver not found: " + e.getMessage() + "</h3>");
        }
    }
}
