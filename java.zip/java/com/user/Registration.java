package com.user;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/Register")
public class Registration extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uname = request.getParameter("name");
        String pwd = request.getParameter("pwd");
        String cnfpwd = request.getParameter("cnfpwd");

        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        if (!pwd.equals(cnfpwd)) {
            out.println("Passwords do not match. Please try again.");
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); 
            
            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/userdetails", "root", "2341");
                 PreparedStatement ps = con.prepareStatement("INSERT INTO login (name, password) VALUES (?, ?)")) {

                ps.setString(1, uname);
                ps.setString(2, pwd);

                int count = ps.executeUpdate();
                if (count > 0) {
                    out.println("Successfully registered!");
                    response.sendRedirect("Login.html");
                } else {
                    out.println("Registration failed. Please try again.");
                }
            } 
        } 
        catch (ClassNotFoundException e) {
            out.println("JDBC Driver not found: " + e.getMessage());
        } 
        catch (SQLException e) {
            out.println("Database error: " + e.getMessage());
        }
    }
}
