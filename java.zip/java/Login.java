import java.io.IOException;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/Login")
public class Login extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("pwd");

        response.setContentType("text/html");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Add this line

            Connection conn = DBUtil.getConnection();
            String query = "SELECT name FROM users WHERE email = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, email);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String name = rs.getString("name");

                HttpSession session = request.getSession();
                session.setAttribute("user", name);

                response.sendRedirect("Dashboard.html");
            } else {
                response.getWriter().println("<h3 style='text-align:center;'>Invalid credentials. <a href='Login.html'>Try again</a></h3>");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println(
                "<h3 style='text-align:center;'>Database error: " + e.getMessage() + "</h3>"
            );
        }
    }
}
