import java.io.IOException;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/CreateAccountServlet")
public class CreateAccountServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accNumber = request.getParameter("account_number");
        String accName = request.getParameter("accName");
        String accType = request.getParameter("accType");
        String balanceStr = request.getParameter("balance");

        response.setContentType("text/html");

        // Basic validation
        if (accNumber == null || accName == null || accType == null || balanceStr == null ||
            accNumber.trim().isEmpty() || accName.trim().isEmpty() || accType.trim().isEmpty() || balanceStr.trim().isEmpty()) {
            response.getWriter().println("<h3 style='color:red;'>All fields are required. <a href='Create.html'>Try again</a></h3>");
            return;
        }

        double balance;
        try {
            balance = Double.parseDouble(balanceStr);
        } catch (NumberFormatException e) {
            response.getWriter().println("<h3 style='color:red;'>Invalid balance amount. <a href='Create.html'>Try again</a></h3>");
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/user_auth", "root", "2341");

            String insertQuery = "INSERT INTO accounts (account_number, name, account_type, balance) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(insertQuery);
            ps.setString(1, accNumber);
            ps.setString(2, accName);
            ps.setString(3, accType);
            ps.setDouble(4, balance);

            int rowsInserted = ps.executeUpdate();

            if (rowsInserted > 0) {
                response.getWriter().println("<h3 style='color:green;'>Account created successfully!</h3>");
                response.getWriter().println("<h4>Your Account Number: " + accNumber + "</h4>");
                response.getWriter().println("<a href='Dashboard.html'>Go to Dashboard</a>");
            } else {
                response.getWriter().println("<h3 style='color:red;'>Failed to create account. <a href='Create.html'>Try again</a></h3>");
            }

            ps.close();
            conn.close();

        } catch (ClassNotFoundException e) {
            response.getWriter().println("<h3 style='color:red;'>JDBC Driver not found: " + e.getMessage() + "</h3>");
        } catch (SQLException e) {
            response.getWriter().println("<h3 style='color:red;'>Database error: " + e.getMessage() + "</h3>");
        }
    }
}
