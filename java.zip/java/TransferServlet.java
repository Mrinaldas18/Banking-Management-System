import java.io.*;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/Transfer")
public class TransferServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String fromAcc = request.getParameter("fromAcc");
        String toAcc = request.getParameter("toAcc");
        String amountStr = request.getParameter("amount");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (fromAcc == null || toAcc == null || amountStr == null ||
            fromAcc.trim().isEmpty() || toAcc.trim().isEmpty() || amountStr.trim().isEmpty()) {
            out.println("<h3 style='color:red;'>All fields are required. <a href='Transfer.html'>Try again</a></h3>");
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
            if (amount <= 0) {
                out.println("<h3 style='color:red;'>Amount must be greater than zero. <a href='Transfer.html'>Try again</a></h3>");
                return;
            }
        } catch (NumberFormatException e) {
            out.println("<h3 style='color:red;'>Invalid amount. <a href='Transfer.html'>Try again</a></h3>");
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/user_auth", "root", "2341");

            conn.setAutoCommit(false); // Enable transaction

            // Check balances
            PreparedStatement checkFrom = conn.prepareStatement("SELECT balance FROM accounts WHERE account_number = ?");
            checkFrom.setString(1, fromAcc);
            ResultSet fromRs = checkFrom.executeQuery();

            if (!fromRs.next()) {
                out.println("<h3 style='color:red;'>Sender account not found. <a href='Transfer.html'>Try again</a></h3>");
                return;
            }

            double senderBalance = fromRs.getDouble("balance");

            if (senderBalance < amount) {
                out.println("<h3 style='color:red;'>Insufficient funds. <a href='Transfer.html'>Try again</a></h3>");
                return;
            }

            PreparedStatement checkTo = conn.prepareStatement("SELECT balance FROM accounts WHERE account_number = ?");
            checkTo.setString(1, toAcc);
            ResultSet toRs = checkTo.executeQuery();

            if (!toRs.next()) {
                out.println("<h3 style='color:red;'>Receiver account not found. <a href='Transfer.html'>Try again</a></h3>");
                return;
            }

            // Update balances
            PreparedStatement deduct = conn.prepareStatement("UPDATE accounts SET balance = balance - ? WHERE account_number = ?");
            deduct.setDouble(1, amount);
            deduct.setString(2, fromAcc);
            deduct.executeUpdate();

            PreparedStatement add = conn.prepareStatement("UPDATE accounts SET balance = balance + ? WHERE account_number = ?");
            add.setDouble(1, amount);
            add.setString(2, toAcc);
            add.executeUpdate();

            // Log transactions
            PreparedStatement logSender = conn.prepareStatement("INSERT INTO transactions (account_number, type, amount) VALUES (?, 'Transfer Out', ?)");
            logSender.setString(1, fromAcc);
            logSender.setDouble(2, amount);
            logSender.executeUpdate();

            PreparedStatement logReceiver = conn.prepareStatement("INSERT INTO transactions (account_number, type, amount) VALUES (?, 'Transfer In', ?)");
            logReceiver.setString(1, toAcc);
            logReceiver.setDouble(2, amount);
            logReceiver.executeUpdate();

            conn.commit(); // Commit all changes

            out.println("<h3 style='color:green;'>₹" + amount + " transferred successfully from account " + fromAcc + " to " + toAcc + ".</h3>");
            out.println("<div style='margin-top:20px;'><a href='Dashboard.html' style='color:#00ffff; text-decoration:none;'>← Back to Dashboard</a></div>");

            // Close all
            logSender.close();
            logReceiver.close();
            deduct.close();
            add.close();
            checkFrom.close();
            checkTo.close();
            conn.close();

        } catch (Exception e) {
            out.println("<h3 style='color:red;'>Error: " + e.getMessage() + "</h3>");
        }
    }
}
