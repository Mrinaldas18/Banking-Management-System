import java.io.*;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/TransactionHistory")
public class TransactionHistory extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accNo = request.getParameter("accNo");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (accNo == null || accNo.trim().isEmpty()) {
            out.println("<h3 style='color:red;'>Account number required.</h3>");
            return;
        }

        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Transaction History</title>");
        out.println("<style>");
        out.println("body { font-family: 'Poppins', sans-serif; background: #1e1e2f; color: #fff; padding: 40px; }");
        out.println("h2 { color: #00ffff; text-align: center; }");
        out.println("table { width: 100%; border-collapse: collapse; margin-top: 30px; }");
        out.println("th, td { padding: 12px; text-align: center; border-bottom: 1px solid #444; }");
        out.println("th { background-color: #00ffff; color: #000; }");
        out.println("a { display: block; margin-top: 20px; text-align: center; color: #00ffff; text-decoration: none; font-weight: bold; }");
        out.println("p { text-align: center; margin-top: 20px; }");
        out.println("</style></head><body>");

        out.println("<h2>Transaction History</h2>");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/user_auth", "root", "2341");

            String sql = "SELECT * FROM transactions WHERE account_number = ? ORDER BY transaction_date DESC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, accNo);
            ResultSet rs = ps.executeQuery();

            boolean hasData = false;
            out.println("<table>");
            out.println("<tr><th>Transaction ID</th><th>Type</th><th>Amount</th><th>Date</th></tr>");

            while (rs.next()) {
                hasData = true;
                out.println("<tr><td>" + rs.getInt("id") + "</td><td>" +
                            rs.getString("type") + "</td><td>₹" +
                            rs.getDouble("amount") + "</td><td>" +
                            rs.getTimestamp("transaction_date") + "</td></tr>");
            }

            out.println("</table>");

            if (!hasData) {
                out.println("<p>No transactions found for this account.</p>");
            }

            out.println("<a href='Dashboard.html'>← Back to Dashboard</a>");

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
        }

        out.println("</body></html>");
    }
}
