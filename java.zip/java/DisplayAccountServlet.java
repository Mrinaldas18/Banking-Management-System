import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/DisplayAccountServlet")
public class DisplayAccountServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accName = request.getParameter("accName");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (accName == null || accName.trim().isEmpty()) {
            out.println("<h3 style='color:red;'>Account name is required. <a href='Display.html'>Try again</a></h3>");
            return;
        }

        try {
            // Load JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Database connection
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/user_auth", "root", "2341");

            // Query account details
            String query = "SELECT * FROM accounts WHERE name = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, accName);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // Account found
                out.println("<h2 style='color:lightgreen;'>Account Details</h2>");
                out.println("<p><strong>Name:</strong> " + rs.getString("name") + "</p>");
                out.println("<p><strong>Account Type:</strong> " + rs.getString("account_type") + "</p>");
                out.println("<p><strong>Balance:</strong> ₹" + rs.getDouble("balance") + "</p>");
                out.println("<br><a href='Display.html'>Search another</a> | <a href='Dashboard.html'>Back to Dashboard</a>");
            } else {
                // Not found
                out.println("<h3 style='color:red;'>No account found with that name. <a href='Display.html'>Try again</a></h3>");
            }

            rs.close();
            ps.close();
            conn.close();

        } catch (ClassNotFoundException e) {
            out.println("<h3 style='color:red;'>JDBC Driver not found: " + e.getMessage() + "</h3>");
        } catch (SQLException e) {
            out.println("<h3 style='color:red;'>Database error: " + e.getMessage() + "</h3>");
        }
    }
}
